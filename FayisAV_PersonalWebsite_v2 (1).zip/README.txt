
HOW TO UPLOAD YOUR WEBSITE TO GITHUB PAGES:

1. Go to https://github.com and sign in.
2. Create a new repository named: yourusername.github.io
   (Replace 'yourusername' with your GitHub username)
3. Click 'Add file' > 'Upload files'.
4. Upload ALL the files in this ZIP (index.html, style.css, profile.jpg).
5. Click 'Commit changes'.
6. After a few minutes, your website will be live at:
   https://yourusername.github.io

To update anything later, just edit the files in GitHub.
